import re

def count_alphabet_occurrences(file_path):
    try:
        with open(file_path, 'r') as file:
            content = file.read()

        # Use regular expression to extract only English alphabet characters
        alphabet_chars = re.findall(r'[a-zA-Z]', content)

        # Count occurrences using a dictionary
        alphabet_counts = {}
        for char in alphabet_chars:
            char = char.upper()  # Convert to uppercase to make it case-insensitive
            alphabet_counts[char] = alphabet_counts.get(char, 0) + 1

        # Sort the dictionary items by count in descending order
        sorted_alphabet_counts = sorted(alphabet_counts.items(), key=lambda x: x[1], reverse=True)

        # Extract the sorted alphabet characters
        sorted_alphabet = [item[0] for item in sorted_alphabet_counts]

        print(sorted_alphabet)

    except FileNotFoundError:
        print(f"File '{file_path}' not found. Please check the file path.")

if __name__ == "__main__":
    file_path = "input_7_2.txt"
    count_alphabet_occurrences(file_path)
