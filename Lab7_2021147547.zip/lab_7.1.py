import re

def find_function_declarations_and_calls(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()

    function_pattern = re.compile(r'\bdef\s+(\w+)\s*\([^)]*\)\s*:')
    call_pattern = re.compile(r'\b(\w+)\s*\([^)]*\)\s*')

    function_calls = {}
    
    for i, line in enumerate(lines, start=1):
        function_match = function_pattern.match(line)
        call_matches = call_pattern.findall(line)

        if function_match:
            function_name = function_match.group(1)
            if function_name not in function_calls:
                function_calls[function_name] = {"def": i, "calls": []}
        
        for call in call_matches:
            if call in function_calls:
                function_calls[call]["calls"].append(i)

    for function_name, details in function_calls.items():
        def_line = details["def"]
        calls_lines = details["calls"]
        calls_str = ', '.join(map(str, calls_lines))
        
        print(f"{function_name}: def in {def_line}, calls in [{calls_str}]")

if __name__ == "__main__":
    file_path = "input_7_1.txt"
    find_function_declarations_and_calls(file_path)
